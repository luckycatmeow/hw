from io import StringIO
import copy

class NetworkComponent:
    def print_me(self, prefix="", is_last=True):
        raise NotImplementedError("This method should be overridden.")

    def clone(self):
        raise NotImplementedError("This method should be overridden.")

class Network(NetworkComponent):
    def __init__(self, name):
        self.name = name
        self.hosts = []

    def add_host(self, host):
        self.hosts.append(host)

    def print_me(self, prefix="", is_last=True):
        output = StringIO()
        output.write(f"{prefix}Network: {self.name}\n")
        for index, host in enumerate(self.hosts):
            is_last_host = index == len(self.hosts) - 1
            output.write(host.print_me(prefix + (" " if is_last else "| ") + "+-", is_last_host))
        return output.getvalue()

    def clone(self):
        return copy.deepcopy(self)

class Host(NetworkComponent):
    def __init__(self, name, ip_address):
        self.name = name
        self.ip_address = ip_address
        self.components = []

    def add_component(self, component):
        self.components.append(component)

    def print_me(self, prefix="", is_last=True):
        output = StringIO()
        output.write(f"{prefix}Host: {self.name}\n")
        output.write(f"{prefix} {'' if is_last else '| '}+-{self.ip_address}\n")
        for index, component in enumerate(self.components):
            is_last_component = index == len(self.components) - 1
            output.write(component.print_me(prefix + (" " if is_last else "| ") + " ", is_last_component))
        return output.getvalue()

    def clone(self):
        return copy.deepcopy(self)

class HardwareComponent(NetworkComponent):
    def __init__(self, name):
        self.name = name

class CPU(HardwareComponent):
    def __init__(self, cores, frequency):
        super().__init__("CPU")
        self.cores = cores
        self.frequency = frequency

    def print_me(self, prefix="", is_last=True):
        return f"{prefix} {'' if is_last else '| '}+-{self.name}, {self.cores} cores @ {self.frequency}MHz\n"

    def clone(self):
        return copy.deepcopy(self)

class Memory(HardwareComponent):
    def __init__(self, size):
        super().__init__("Memory")
        self.size = size

    def print_me(self, prefix="", is_last=True):
        return f"{prefix} {'' if is_last else '| '}+-{self.name}, {self.size} MiB\n"

    def clone(self):
        return copy.deepcopy(self)

class Disk(HardwareComponent):
    def __init__(self, size):
        super().__init__("HDD")
        self.size = size
        self.partitions = []

    def add_partition(self, partition):
        self.partitions.append(partition)

    def print_me(self, prefix="", is_last=True):
        output = StringIO()
        output.write(f"{prefix} {'' if is_last else '| '}+-{self.name}, {self.size} GiB\n")
        for index, partition in enumerate(self.partitions):
            is_last_partition = index == len(self.partitions) - 1
            output.write(partition.print_me(prefix + (" " if is_last else "| ") + " ", is_last_partition))
        return output.getvalue()

    def clone(self):
        return copy.deepcopy(self)

class Partition(HardwareComponent):
    def __init__(self, size, label):
        super().__init__("Partition")
        self.size = size
        self.label = label

    def print_me(self, prefix="", is_last=True):
        return f"{prefix} {'' if is_last else '| '}+-[{self.label}]: {self.size} GiB\n"

    def clone(self):
        return copy.deepcopy(self)

if __name__ == "__main__":
    network = Network("MISIS network")

    host1 = Host("server1.misis.ru", "192.168.1.1")
    host1.add_component(CPU(4, 2500))
    host1.add_component(Memory(16000))

    host2 = Host("server2.misis.ru", "10.0.0.1")
    host2.add_component(CPU(8, 3200))
    disk = Disk(2000)
    disk.add_partition(Partition(500, "system"))
    disk.add_partition(Partition(1500, "data"))
    host2.add_component(disk)

    network.add_host(host1)
    network.add_host(host2)

    print(network.print_me())
