import requests
from bs4 import BeautifulSoup

class TextFile:
    def __init__(self, filename):
        self.filename = filename

    def write(self, data):
        with open(self.filename, 'w', encoding='utf-8') as file:
            file.write(data)

    def read(self):
        with open(self.filename, 'r', encoding='utf-8') as file:
            return file.read()

class Database:
    def __init__(self, db_name):
        self.db_name = db_name
        self.data = []

    def write(self, data):
        self.data.append(data)

    def read(self):
        # Здесь вам нужно определить, как вы хотите получать данные
        # Например, если вы хотите просто вернуть данные, которые были записаны
        return self.data

class NetworkResource:
    def __init__(self, url):
        self.url = url
        self.data = None

    def write(self, data):
        self.data = data

    def read(self):
        # Получаем данные с сервера
        try:
            response = requests.get(self.url)
            response.raise_for_status()  # Проверяем на ошибки HTTP
            soup = BeautifulSoup(response.text, 'html.parser')
            # Извлекаем текст из HTML (например, из тега <body>)
            return soup.get_text()
        except requests.exceptions.RequestException as e:
            print(f"Ошибка при получении данных: {e}")
            return None

def process_data(data_source, data=None):
    if data:
        data_source.write(data)
    return data_source.read()

# Пример использования
text_file = TextFile("document.txt")
database = Database("users.db")
network = NetworkResource("https://ru.wikipedia.org/wiki/Ирбис")

print(process_data(text_file, "Новый текст"))
print(process_data(database, {"name": "Иван", "age": 25}))
print(process_data(network, "POST data"))
