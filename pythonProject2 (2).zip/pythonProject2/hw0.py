# Базовый класс Animal
class Animal:
    def __init__(self, name):
        self.name = name

    def speak(self):
        raise NotImplementedError("Subclasses must implement this method")

class Mammal(Animal):
    def __init__(self, name):
        super().__init__(name)

class Dog(Mammal):
    def speak(self):
        return "Woof!"

class Cat(Mammal):
    def speak(self):
        return "Meow!"

class Horse(Mammal):
    def speak(self):
        return "Neigh!"

class Bird(Animal):
    def __init__(self, name):
        super().__init__(name)

class Eagle(Bird):
    def speak(self):
        return "Screech!"

class Penguin(Bird):
    def speak(self):
        return "Honk!"

class Reptile(Animal):
    def __init__(self, name):
        super().__init__(name)

class Snake(Reptile):
    def speak(self):
        return "Hiss!"

class Turtle(Reptile):
    def speak(self):
        return "..."

if __name__ == "__main__":
    dog = Dog("Buddy")
    cat = Cat("Whiskers")
    horse = Horse("Spirit")

    eagle = Eagle("Eddie")
    penguin = Penguin("Pingu")

    snake = Snake("Slither")
    turtle = Turtle("Shelly")

    print(f"{dog.name} says: {dog.speak()}")
    print(f"{cat.name} says: {cat.speak()}")
    print(f"{horse.name} says: {horse.speak()}")

    print(f"{eagle.name} says: {eagle.speak()}")
    print(f"{penguin.name} says: {penguin.speak()}")

    print(f"{snake.name} says: {snake.speak()}")
    print(f"{turtle.name} says: {turtle.speak()}")
